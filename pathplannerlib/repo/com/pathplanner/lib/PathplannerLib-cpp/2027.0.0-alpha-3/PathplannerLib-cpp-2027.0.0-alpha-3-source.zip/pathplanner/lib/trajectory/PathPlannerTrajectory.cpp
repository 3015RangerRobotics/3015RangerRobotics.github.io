#include "pathplanner/lib/trajectory/PathPlannerTrajectory.h"
#include "pathplanner/lib/path/PathPlannerPath.h"
#include "pathplanner/lib/events/ScheduleCommandEvent.h"
#include "pathplanner/lib/events/CancelCommandEvent.h"
#include "pathplanner/lib/events/TriggerEvent.h"
#include "pathplanner/lib/events/PointTowardsZoneEvent.h"
#include "pathplanner/lib/events/OneShotTriggerEvent.h"
#include <memory>
#include <wpi/units/force.hpp>
#include <wpi/units/torque.hpp>

using namespace pathplanner;

PathPlannerTrajectory::PathPlannerTrajectory(
		std::shared_ptr<PathPlannerPath> path,
		const wpi::math::ChassisVelocities &startingSpeeds,
		const wpi::math::Rotation2d &startingRotation,
		const RobotConfig &config) {
	if (path->isChoreoPath()) {
		PathPlannerTrajectory traj = path->getIdealTrajectory(config).value();
		m_states = traj.m_states;
		m_events = traj.m_events;
	} else {
		// Create all states
		generateStates(m_states, path, startingRotation, config);

		// Set the initial module velocities
		wpi::math::ChassisVelocities fieldStartingSpeeds =
				startingSpeeds.ToFieldRelative(m_states[0].pose.Rotation());
		auto initialStates = config.toSwerveModuleVelocitys(
				fieldStartingSpeeds);
		for (size_t m = 0; m < config.numModules; m++) {
			m_states[0].moduleStates[m].speed = initialStates[m].velocity;
		}
		m_states[0].time = 0.0_s;
		m_states[0].fieldSpeeds = fieldStartingSpeeds;
		m_states[0].linearVelocity = wpi::units::math::hypot(
				fieldStartingSpeeds.vx, fieldStartingSpeeds.vy);

		// Forward pass
		forwardAccelPass(m_states, config);

		// Set the final module velocities
		wpi::math::Translation2d endSpeedTrans(
				wpi::units::meter_t { path->getGoalEndState().getVelocity()() },
				m_states[m_states.size() - 1].heading);
		wpi::math::ChassisVelocities endFieldSpeeds {
				wpi::units::meters_per_second_t { endSpeedTrans.X()() },
				wpi::units::meters_per_second_t { endSpeedTrans.Y()() },
				0_rad_per_s };
		auto endStates = config.toSwerveModuleVelocitys(
				endFieldSpeeds.ToRobotRelative(
						m_states[m_states.size() - 1].pose.Rotation()));
		for (size_t m = 0; m < config.numModules; m++) {
			m_states[m_states.size() - 1].moduleStates[m].speed =
					endStates[m].velocity;
		}
		m_states[m_states.size() - 1].fieldSpeeds = endFieldSpeeds;
		m_states[m_states.size() - 1].linearVelocity =
				path->getGoalEndState().getVelocity();

		// Reverse pass
		reverseAccelPass(m_states, config);

		std::vector < std::shared_ptr < Event >> unaddedEvents;
		for (EventMarker marker : path->getEventMarkers()) {
			unaddedEvents.emplace_back(
					std::make_shared < ScheduleCommandEvent
							> (wpi::units::second_t {
									marker.getWaypointRelativePos() }, marker.getCommand()));

			if (marker.getEndWaypointRelativePos() >= 0.0) {
				// This marker is zoned
				unaddedEvents.emplace_back(
						std::make_shared < CancelCommandEvent
								> (wpi::units::second_t {
										marker.getEndWaypointRelativePos() }, marker.getCommand()));
				unaddedEvents.emplace_back(
						std::make_shared < TriggerEvent
								> (wpi::units::second_t {
										marker.getWaypointRelativePos() }, marker.getTriggerName(), true));
				unaddedEvents.emplace_back(
						std::make_shared < TriggerEvent
								> (wpi::units::second_t {
										marker.getEndWaypointRelativePos() }, marker.getTriggerName(), false));
			} else {
				unaddedEvents.emplace_back(
						std::make_shared < OneShotTriggerEvent
								> (wpi::units::second_t {
										marker.getWaypointRelativePos() }, marker.getTriggerName()));
			}
		}
		for (PointTowardsZone zone : path->getPointTowardsZones()) {
			unaddedEvents.emplace_back(
					std::make_shared < PointTowardsZoneEvent
							> (wpi::units::second_t {
									zone.getMinWaypointRelativePos() }, zone.getName(), true));
			unaddedEvents.emplace_back(
					std::make_shared < PointTowardsZoneEvent
							> (wpi::units::second_t {
									zone.getMaxWaypointRelativePos() }, zone.getName(), false));
		}
		std::sort(unaddedEvents.begin(), unaddedEvents.end(),
				[](auto left, auto right) {
					return left->getTimestamp() < right->getTimestamp();
				});

		// Loop back over and calculate time and module torque
		for (size_t i = 1; i < m_states.size(); i++) {
			PathPlannerTrajectoryState &prevState = m_states[i - 1];
			PathPlannerTrajectoryState &state = m_states[i];

			wpi::units::meters_per_second_t v0 = prevState.linearVelocity;
			wpi::units::meters_per_second_t v = state.linearVelocity;
			wpi::units::meters_per_second_t sumV = v + v0;
			if (wpi::units::math::abs(sumV) < 1e-6_mps
					|| wpi::units::math::abs(state.deltaPos) < 1e-6_m) {
				state.time = prevState.time;
				if (i != 1) {
					prevState.feedforwards = m_states[i - 2].feedforwards;
				} else {
					prevState.feedforwards = DriveFeedforwards::zeros(
							config.numModules);
				}
			} else {
				wpi::units::second_t dt = (2 * state.deltaPos) / sumV;
				state.time = prevState.time + dt;

				wpi::math::ChassisVelocities prevRobotSpeeds =
						prevState.fieldSpeeds.ToRobotRelative(
								prevState.pose.Rotation());
				wpi::math::ChassisVelocities robotSpeeds =
						state.fieldSpeeds.ToRobotRelative(
								state.pose.Rotation());

				auto chassisAccelX = (robotSpeeds.vx - prevRobotSpeeds.vx) / dt;
				auto chassisAccelY = (robotSpeeds.vy - prevRobotSpeeds.vy) / dt;
				auto chassisForceX = chassisAccelX * config.mass;
				auto chassisForceY = chassisAccelY * config.mass;

				auto angularAccel = (robotSpeeds.omega - prevRobotSpeeds.omega)
						/ dt;
				auto angTorque = angularAccel * config.MOI;
				wpi::math::ChassisVelocities chassisForces {
						wpi::units::meters_per_second_t { chassisForceX() },
						wpi::units::meters_per_second_t { chassisForceY() },
						wpi::units::radians_per_second_t { angTorque() }, };

				auto wheelForces = config.chassisForcesToWheelForceVectors(
						chassisForces);
				std::vector < wpi::units::meters_per_second_squared_t > accelFF;
				std::vector < wpi::units::newton_t > linearForceFF;
				std::vector < wpi::units::ampere_t > torqueCurrentFF;
				std::vector < wpi::units::newton_t > forceXFF;
				std::vector < wpi::units::newton_t > forceYFF;
				for (size_t m = 0; m < config.numModules; m++) {
					wpi::units::meter_t wheelForceDist = wheelForces[m].Norm();
					wpi::units::newton_t appliedForce { 0.0 };
					if (wheelForceDist() > 1e-6) {
						appliedForce = wpi::units::newton_t { wheelForceDist()
								* (wheelForces[m].Angle()
										- state.moduleStates[m].angle).Cos() };
					}
					wpi::units::newton_meter_t wheelTorque = appliedForce
							* config.moduleConfig.wheelRadius;
					wpi::units::ampere_t torqueCurrent =
							config.moduleConfig.driveMotor.Current(wheelTorque);

					accelFF.emplace_back(
							(state.moduleStates[m].speed
									- prevState.moduleStates[m].speed) / dt);
					linearForceFF.emplace_back(appliedForce);
					torqueCurrentFF.emplace_back(torqueCurrent);
					forceXFF.emplace_back(
							wpi::units::newton_t { wheelForces[m].X()() });
					forceYFF.emplace_back(
							wpi::units::newton_t { wheelForces[m].Y()() });
				}
				prevState.feedforwards = DriveFeedforwards { accelFF,
						linearForceFF, torqueCurrentFF, forceXFF, forceYFF };
			}

			// Un-added events have their timestamp set to a waypoint relative position
			// When adding the event to this trajectory, set its timestamp properly
			while (!unaddedEvents.empty()
					&& std::abs(
							unaddedEvents[0]->getTimestamp()()
									- prevState.waypointRelativePos)
							<= std::abs(
									unaddedEvents[0]->getTimestamp()()
											- state.waypointRelativePos)) {
				unaddedEvents[0]->setTimestamp(prevState.time);
				m_events.emplace_back(unaddedEvents[0]);
				unaddedEvents.erase(unaddedEvents.begin());
			}

		}

		while (!unaddedEvents.empty()) {
			// There are events that need to be added to the last state
			unaddedEvents[0]->setTimestamp(m_states[m_states.size() - 1].time);
			m_events.emplace_back(unaddedEvents[0]);
			unaddedEvents.erase(unaddedEvents.begin());
		}

		// Create feedforwards for the end state
		m_states[m_states.size() - 1].feedforwards = DriveFeedforwards::zeros(
				config.numModules);
	}
}

PathPlannerTrajectoryState PathPlannerTrajectory::sample(
		const wpi::units::second_t time) {
	if (time <= getInitialState().time)
		return getInitialState();
	if (time >= getTotalTime())
		return getEndState();

	size_t low = 1;
	size_t high = getStates().size() - 1;

	while (low != high) {
		size_t mid = (low + high) / 2;
		if (getState(mid).time < time) {
			low = mid + 1;
		} else {
			high = mid;
		}
	}

	PathPlannerTrajectoryState sample = getState(low);
	PathPlannerTrajectoryState prevSample = getState(low - 1);

	if (wpi::units::math::abs(sample.time - prevSample.time) < 1E-3_s)
		return sample;

	return prevSample.interpolate(sample,
			(time() - prevSample.time()) / (sample.time() - prevSample.time()));
}

void PathPlannerTrajectory::generateStates(
		std::vector<PathPlannerTrajectoryState> &states,
		std::shared_ptr<PathPlannerPath> path,
		const wpi::math::Rotation2d &startingRotation,
		const RobotConfig &config) {
	size_t prevRotationTargetIdx = 0;
	wpi::math::Rotation2d prevRotationTargetRot = startingRotation;
	size_t nextRotationTargetIdx = getNextRotationTargetIdx(path, 0);
	wpi::math::Rotation2d nextRotationTargetRot = path->getPoint(
			nextRotationTargetIdx).rotationTarget.value().getTarget();

	for (size_t i = 0; i < path->numPoints(); i++) {
		PathPoint p = path->getPoint(i);

		if (i > nextRotationTargetIdx) {
			prevRotationTargetIdx = nextRotationTargetIdx;
			prevRotationTargetRot = nextRotationTargetRot;
			nextRotationTargetIdx = getNextRotationTargetIdx(path, i);
			nextRotationTargetRot =
					path->getPoint(nextRotationTargetIdx).rotationTarget.value().getTarget();
		}

		// Holonomic rotation is interpolated. We use the distance along the path
		// to calculate how much to interpolate since the distribution of path points
		// is not the same along the whole segment
		double t =
				(path->getPoint(i).distanceAlongPath
						- path->getPoint(prevRotationTargetIdx).distanceAlongPath)()
						/ (path->getPoint(nextRotationTargetIdx).distanceAlongPath
								- path->getPoint(prevRotationTargetIdx).distanceAlongPath)();
		wpi::math::Rotation2d holonomicRot = cosineInterpolate(
				prevRotationTargetRot, nextRotationTargetRot, t);

		wpi::math::Pose2d robotPose(p.position, holonomicRot);
		PathPlannerTrajectoryState state;
		state.pose = robotPose;
		state.constraints = p.constraints.value_or(
				path->getGlobalConstraints());
		state.waypointRelativePos = p.waypointRelativePos;

		// Calculate robot heading
		if (i != path->numPoints() - 1) {
			wpi::math::Translation2d headingTranslation =
					path->getPoint(i + 1).position - state.pose.Translation();
			if (headingTranslation.Norm()() <= 1e-6) {
				state.heading = wpi::math::Rotation2d();
			} else {
				state.heading = headingTranslation.Angle();
			}
		} else {
			state.heading = states[i - 1].heading;
		}

		if (!config.isHolonomic) {
			state.pose = wpi::math::Pose2d(state.pose.Translation(),
					state.heading);
		}

		if (i != 0) {
			state.deltaPos = state.pose.Translation().Distance(
					states[i - 1].pose.Translation());
			state.deltaRot = state.pose.Rotation()
					- states[i - 1].pose.Rotation();
		}

		for (size_t m = 0; m < config.numModules; m++) {
			SwerveModuleTrajectoryState s;
			s.fieldPos = state.pose.Translation()
					+ config.moduleLocations[m].RotateBy(state.pose.Rotation());

			if (i != 0) {
				s.deltaPos = s.fieldPos.Distance(
						states[i - 1].moduleStates[m].fieldPos);
			}

			state.moduleStates.emplace_back(s);
		}

		states.emplace_back(state);
	}

	// Calculate module headings
	for (size_t i = 0; i < states.size(); i++) {
		for (size_t m = 0; m < config.numModules; m++) {
			if (i != states.size() - 1) {
				wpi::math::Translation2d fieldTranslation =
						states[i + 1].moduleStates[m].fieldPos
								- states[i].moduleStates[m].fieldPos;
				if (fieldTranslation.Norm()() <= 1e-6) {
					states[i].moduleStates[m].fieldAngle =
							wpi::math::Rotation2d();
				} else {
					states[i].moduleStates[m].fieldAngle =
							fieldTranslation.Angle();
				}
				states[i].moduleStates[m].angle =
						states[i].moduleStates[m].fieldAngle
								- states[i].pose.Rotation();
			} else {
				states[i].moduleStates[m].fieldAngle =
						states[i - 1].moduleStates[m].fieldAngle;
				states[i].moduleStates[m].angle =
						states[i].moduleStates[m].fieldAngle
								- states[i].pose.Rotation();
			}
		}
	}
}

void PathPlannerTrajectory::forwardAccelPass(
		std::vector<PathPlannerTrajectoryState> &states,
		const RobotConfig &config) {
	for (size_t i = 1; i < states.size() - 1; i++) {
		PathPlannerTrajectoryState &prevState = states[i - 1];
		PathPlannerTrajectoryState &state = states[i];
		PathPlannerTrajectoryState &nextState = states[i + 1];

		// Calculate the linear force vector and torque acting on the whole robot
		wpi::math::Translation2d linearForceVec;
		wpi::units::newton_meter_t totalTorque = 0_Nm;
		for (size_t m = 0; m < config.numModules; m++) {
			wpi::units::meters_per_second_t lastVel =
					prevState.moduleStates[m].speed;
			// This pass will only be handling acceleration of the robot, meaning that the "torque"
			// acting on the module due to friction and other losses will be fighting the motor
			wpi::units::radians_per_second_t lastVelRadPerSec { lastVel()
					/ config.moduleConfig.wheelRadius() };
			wpi::units::ampere_t currentDraw = wpi::units::math::min(
					config.moduleConfig.driveMotor.Current(lastVelRadPerSec,
							state.constraints.getNominalVoltage()),
					config.moduleConfig.driveCurrentLimit);
			wpi::units::newton_meter_t availableTorque =
					config.moduleConfig.driveMotor.Torque(currentDraw)
							- config.moduleConfig.torqueLoss;
			availableTorque = wpi::units::math::min(availableTorque,
					config.maxTorqueFriction);
			wpi::units::newton_t forceAtCarpet = availableTorque
					/ config.moduleConfig.wheelRadius;

			wpi::math::Translation2d forceVec(wpi::units::meter_t {
					forceAtCarpet() }, state.moduleStates[m].fieldAngle);

			// Add the module force vector to the robot force vector
			linearForceVec = linearForceVec + forceVec;

			// Calculate the torque this module will apply to the robot
			wpi::math::Rotation2d angleToModule =
					(state.moduleStates[m].fieldPos - state.pose.Translation()).Angle();
			wpi::math::Rotation2d theta;
			if (forceVec.Norm()() <= 1e-6) {
				theta = wpi::math::Rotation2d() - angleToModule;
			} else {
				theta = forceVec.Angle() - angleToModule;
			}
			totalTorque += forceAtCarpet * config.modulePivotDistance[m]
					* theta.Sin();
		}

		// Use the robot accelerations to calculate how each module should accelerate
		// Even though kinematics is usually used for velocities, it can still
		// convert chassis accelerations to module accelerations
		wpi::units::radians_per_second_squared_t maxAngAccel =
				state.constraints.getMaxAngularAcceleration();
		wpi::units::radians_per_second_squared_t angularAccel =
				wpi::units::math::min(
						wpi::units::math::max(
								wpi::units::radians_per_second_squared_t {
										(totalTorque / config.MOI)() },
								-maxAngAccel), maxAngAccel);

		wpi::math::Translation2d accelVec = linearForceVec / config.mass();
		wpi::units::meters_per_second_squared_t maxAccel =
				state.constraints.getMaxAcceleration();
		wpi::units::meters_per_second_squared_t accel { accelVec.Norm()() };
		if (accel > maxAccel) {
			accelVec = accelVec * (maxAccel() / accel());
		}

		wpi::math::ChassisVelocities chassisAccel =
				wpi::math::ChassisVelocities { wpi::units::meters_per_second_t {
						accelVec.X()() }, wpi::units::meters_per_second_t {
						accelVec.Y()() }, wpi::units::radians_per_second_t {
						angularAccel() } }.ToRobotRelative(
						state.pose.Rotation());
		auto accelStates = config.toSwerveModuleVelocitys(chassisAccel);
		for (size_t m = 0; m < config.numModules; m++) {
			wpi::units::meters_per_second_squared_t moduleAcceleration {
					wpi::units::math::abs(accelStates[m].velocity)() };

			// Calculate the module velocity at the current state
			// vf^2 = v0^2 + 2ad
			state.moduleStates[m].speed =
					wpi::units::math::sqrt(
							wpi::units::math::abs(
									wpi::units::math::pow < 2
											> (prevState.moduleStates[m].speed)
													+ (2 * moduleAcceleration
															* state.moduleStates[m].deltaPos)));

			wpi::units::meter_t curveRadius = GeometryUtil::calculateRadius(
					prevState.moduleStates[m].fieldPos,
					state.moduleStates[m].fieldPos,
					nextState.moduleStates[m].fieldPos);
			// Find the max velocity that would keep the centripetal force under the friction force
			// Fc = M * v^2 / R
			if (GeometryUtil::isFinite(curveRadius)) {
				wpi::units::meters_per_second_t maxSafeVel =
						wpi::units::math::sqrt(
								(config.wheelFrictionForce
										* wpi::units::math::abs(curveRadius))
										/ (config.mass / config.numModules));
				state.moduleStates[m].speed = wpi::units::math::min(
						state.moduleStates[m].speed, maxSafeVel);
			}
		}

		// Go over the modules again to make sure they take the same amount of time to reach the next
		// state
		wpi::units::second_t maxDT = 0_s;
		wpi::units::second_t realMaxDT = 0_s;
		for (size_t m = 0; m < config.numModules; m++) {
			wpi::math::Rotation2d prevRotDelta = state.moduleStates[m].angle
					- prevState.moduleStates[m].angle;
			wpi::units::meters_per_second_t modVel = state.moduleStates[m].speed;
			wpi::units::second_t dt = nextState.moduleStates[m].deltaPos
					/ modVel;

			if (GeometryUtil::isFinite(dt)) {
				realMaxDT = wpi::units::math::max(dt, realMaxDT);

				if (wpi::units::math::abs(prevRotDelta.Degrees()) < 60_deg) {
					maxDT = wpi::units::math::max(dt, maxDT);
				}
			}
		}

		if (maxDT == 0_s) {
			maxDT = realMaxDT;
		}

		if (maxDT > 0_s) {
			// Recalculate all module velocities with the allowed DT
			for (size_t m = 0; m < config.numModules; m++) {
				wpi::math::Rotation2d prevRotDelta = state.moduleStates[m].angle
						- prevState.moduleStates[m].angle;
				if (wpi::units::math::abs(prevRotDelta.Degrees()) >= 60_deg) {
					continue;
				}

				state.moduleStates[m].speed = nextState.moduleStates[m].deltaPos
						/ maxDT;
			}
		}

		// Use the calculated module velocities to calculate the robot speeds
		wpi::math::ChassisVelocities desiredSpeeds = config.toChassisVelocities(
				state.moduleStates);

		wpi::units::meters_per_second_t maxChassisVel =
				state.constraints.getMaxVelocity();
		wpi::units::radians_per_second_t maxChassisAngVel =
				state.constraints.getMaxAngularVelocity();

		desaturateWheelSpeeds(state.moduleStates, desiredSpeeds,
				config.moduleConfig.maxDriveVelocityMPS, maxChassisVel,
				maxChassisAngVel);

		state.fieldSpeeds =
				config.toChassisVelocities(state.moduleStates).ToFieldRelative(
						state.pose.Rotation());
		state.linearVelocity = wpi::units::math::hypot(state.fieldSpeeds.vx,
				state.fieldSpeeds.vy);
	}
}

void PathPlannerTrajectory::reverseAccelPass(
		std::vector<PathPlannerTrajectoryState> &states,
		const RobotConfig &config) {
	for (size_t i = states.size() - 2; i > 0; i--) {
		PathPlannerTrajectoryState &state = states[i];
		PathPlannerTrajectoryState &nextState = states[i + 1];

		// Calculate the linear force vector and torque acting on the whole robot
		wpi::math::Translation2d linearForceVec;
		wpi::units::newton_meter_t totalTorque = 0_Nm;
		for (size_t m = 0; m < config.numModules; m++) {
			wpi::units::meters_per_second_t lastVel =
					nextState.moduleStates[m].speed;
			// This pass will only be handling deceleration of the robot, meaning that the "torque"
			// acting on the module due to friction and other losses will not be fighting the motor
			wpi::units::radians_per_second_t lastVelRadPerSec { lastVel()
					/ config.moduleConfig.wheelRadius() };
			wpi::units::ampere_t currentDraw = wpi::units::math::min(
					config.moduleConfig.driveMotor.Current(lastVelRadPerSec,
							state.constraints.getNominalVoltage()),
					config.moduleConfig.driveCurrentLimit);
			wpi::units::newton_meter_t availableTorque =
					config.moduleConfig.driveMotor.Torque(currentDraw);
			availableTorque = wpi::units::math::min(availableTorque,
					config.maxTorqueFriction);
			wpi::units::newton_t forceAtCarpet = availableTorque
					/ config.moduleConfig.wheelRadius;

			wpi::math::Translation2d forceVec(wpi::units::meter_t {
					forceAtCarpet() },
					state.moduleStates[m].fieldAngle
							+ wpi::math::Rotation2d(180_deg));

			// Add the module force vector to the robot force vector
			linearForceVec = linearForceVec + forceVec;

			// Calculate the torque this module will apply to the robot
			wpi::math::Rotation2d angleToModule =
					(state.moduleStates[m].fieldPos - state.pose.Translation()).Angle();
			wpi::math::Rotation2d theta;
			if (forceVec.Norm()() <= 1e-6) {
				theta = wpi::math::Rotation2d() - angleToModule;
			} else {
				theta = forceVec.Angle() - angleToModule;
			}
			totalTorque += forceAtCarpet * config.modulePivotDistance[m]
					* theta.Sin();
		}

		// Use the robot accelerations to calculate how each module should accelerate
		// Even though kinematics is usually used for velocities, it can still
		// convert chassis accelerations to module accelerations
		wpi::units::radians_per_second_squared_t maxAngAccel =
				state.constraints.getMaxAngularAcceleration();
		wpi::units::radians_per_second_squared_t angularAccel =
				wpi::units::math::min(
						wpi::units::math::max(
								wpi::units::radians_per_second_squared_t {
										(totalTorque / config.MOI)() },
								-maxAngAccel), maxAngAccel);

		wpi::math::Translation2d accelVec = linearForceVec / config.mass();
		wpi::units::meters_per_second_squared_t maxAccel =
				state.constraints.getMaxAcceleration();
		wpi::units::meters_per_second_squared_t accel { accelVec.Norm()() };
		if (accel > maxAccel) {
			accelVec = accelVec * (maxAccel() / accel());
		}

		wpi::math::ChassisVelocities chassisAccel =
				wpi::math::ChassisVelocities { wpi::units::meters_per_second_t {
						accelVec.X()() }, wpi::units::meters_per_second_t {
						accelVec.Y()() }, wpi::units::radians_per_second_t {
						angularAccel() } }.ToRobotRelative(
						state.pose.Rotation());
		auto accelStates = config.toSwerveModuleVelocitys(chassisAccel);
		for (size_t m = 0; m < config.numModules; m++) {
			wpi::units::meters_per_second_squared_t moduleAcceleration {
					wpi::units::math::abs(accelStates[m].velocity)() };

			// Calculate the module velocity at the current state
			// vf^2 = v0^2 + 2ad
			wpi::units::meters_per_second_t maxVel =
					wpi::units::math::sqrt(
							wpi::units::math::abs(
									wpi::units::math::pow < 2
											> (nextState.moduleStates[m].speed)
													+ (2 * moduleAcceleration
															* nextState.moduleStates[m].deltaPos)));
			state.moduleStates[m].speed = wpi::units::math::min(maxVel,
					state.moduleStates[m].speed);
		}

		// Go over the modules again to make sure they take the same amount of time to reach the next
		// state
		wpi::units::second_t maxDT = 0_s;
		wpi::units::second_t realMaxDT = 0_s;
		for (size_t m = 0; m < config.numModules; m++) {
			wpi::math::Rotation2d prevRotDelta = state.moduleStates[m].angle
					- states[i - 1].moduleStates[m].angle;
			wpi::units::meters_per_second_t modVel = state.moduleStates[m].speed;
			wpi::units::second_t dt = nextState.moduleStates[m].deltaPos
					/ modVel;

			if (GeometryUtil::isFinite(dt)) {
				realMaxDT = wpi::units::math::max(dt, realMaxDT);

				if (wpi::units::math::abs(prevRotDelta.Degrees()) < 60_deg) {
					maxDT = wpi::units::math::max(dt, maxDT);
				}
			}
		}

		if (maxDT == 0_s) {
			maxDT = realMaxDT;
		}

		if (maxDT > 0_s) {
			// Recalculate all module velocities with the allowed DT
			for (size_t m = 0; m < config.numModules; m++) {
				wpi::math::Rotation2d prevRotDelta = state.moduleStates[m].angle
						- states[i - 1].moduleStates[m].angle;
				if (wpi::units::math::abs(prevRotDelta.Degrees()) >= 60_deg) {
					continue;
				}

				state.moduleStates[m].speed = nextState.moduleStates[m].deltaPos
						/ maxDT;
			}
		}

		// Use the calculated module velocities to calculate the robot speeds
		wpi::math::ChassisVelocities desiredSpeeds = config.toChassisVelocities(
				state.moduleStates);

		wpi::units::meters_per_second_t maxChassisVel =
				state.constraints.getMaxVelocity();
		wpi::units::radians_per_second_t maxChassisAngVel =
				state.constraints.getMaxAngularVelocity();

		maxChassisVel = wpi::units::math::min(maxChassisVel,
				state.linearVelocity);
		maxChassisAngVel = wpi::units::math::min(maxChassisAngVel,
				wpi::units::math::abs(state.fieldSpeeds.omega));

		desaturateWheelSpeeds(state.moduleStates, desiredSpeeds,
				config.moduleConfig.maxDriveVelocityMPS, maxChassisVel,
				maxChassisAngVel);

		state.fieldSpeeds =
				config.toChassisVelocities(state.moduleStates).ToFieldRelative(
						state.pose.Rotation());
		state.linearVelocity = wpi::units::math::hypot(state.fieldSpeeds.vx,
				state.fieldSpeeds.vy);
	}
}

void PathPlannerTrajectory::desaturateWheelSpeeds(
		std::vector<SwerveModuleTrajectoryState> &moduleStates,
		const wpi::math::ChassisVelocities &desiredSpeeds,
		wpi::units::meters_per_second_t maxModuleSpeed,
		wpi::units::meters_per_second_t maxTranslationSpeed,
		wpi::units::radians_per_second_t maxRotationSpeed) {
	wpi::units::meters_per_second_t realMaxSpeed = 0_mps;
	for (const SwerveModuleTrajectoryState &s : moduleStates) {
		realMaxSpeed = wpi::units::math::max(realMaxSpeed,
				wpi::units::math::abs(s.speed));
	}

	if (realMaxSpeed == 0_mps) {
		return;
	}

	double translationPct = 0.0;
	if (wpi::units::math::abs(maxTranslationSpeed) > 1e-8_mps) {
		translationPct = std::sqrt(
				std::pow(desiredSpeeds.vx(), 2)
						+ std::pow(desiredSpeeds.vy(), 2))
				/ maxTranslationSpeed();
	}

	double rotationPct = 0.0;
	if (wpi::units::math::abs(maxRotationSpeed) > 1e-8_rad_per_s) {
		rotationPct = std::abs(desiredSpeeds.omega())
				/ std::abs(maxRotationSpeed());
	}

	double maxPct = std::max(translationPct, rotationPct);

	double scale = std::min(1.0, maxModuleSpeed() / realMaxSpeed());
	if (maxPct > 0) {
		scale = std::min(scale, 1.0 / maxPct);
	}

	for (SwerveModuleTrajectoryState &s : moduleStates) {
		s.speed *= scale;
	}
}

size_t PathPlannerTrajectory::getNextRotationTargetIdx(
		std::shared_ptr<PathPlannerPath> path, const size_t startingIndex) {
	size_t idx = path->numPoints() - 1;

	for (size_t i = startingIndex; i < path->numPoints() - 1; i++) {
		if (path->getPoint(i).rotationTarget) {
			idx = i;
			break;
		}
	}

	return idx;
}
